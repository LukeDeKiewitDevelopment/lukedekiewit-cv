"use client";

import clsx from "clsx";
import { type ComponentPropsWithoutRef } from "react";

export type FooterProps = ComponentPropsWithoutRef<"footer">;

export const Footer = ({ className, ...props }: FooterProps) => {
  const currentYear = new Date().getFullYear();

  return (
    <footer
      {...props}
      data-slot="footer"
      className={clsx(
        "flex items-center justify-center p-4 text-center md:p-6 lg:p-8 print:hidden!",
        className,
      )}
    >
      <span className="text-muted-foreground text-7pt w-fit text-center align-middle">
        <i className="not-italic">&copy;</i>&nbsp;
        <time dateTime={String(currentYear)}>{currentYear}</time>&nbsp;
        {`Luke De Kiewit. Built with `}
        <a
          className="hover:text-primary underline transition-colors"
          target="_blank"
          rel="noopener noreferrer nofollow"
          href="https://astro.build/"
        >
          Astro
        </a>
        {", "}
        <a
          className="hover:text-primary underline transition-colors"
          target="_blank"
          rel="noopener noreferrer nofollow"
          href="https://react.dev/"
        >
          React
        </a>
        {", "}
        <a
          className="hover:text-primary underline transition-colors"
          target="_blank"
          rel="noopener noreferrer nofollow"
          href="https://tailwindcss.com/"
        >
          Tailwind CSS
        </a>
        {" and "}
        <a
          className="hover:text-primary underline transition-colors"
          target="_blank"
          rel="noopener noreferrer nofollow"
          href="https://ui.shadcn.com/"
        >
          shadcn/ui
        </a>
        {"."}
      </span>
    </footer>
  );
};
